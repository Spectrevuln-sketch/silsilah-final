<?php

return [
    'address'       => 'Address',
    'location_name' => 'Location Name',
    'latitude'      => 'Latitude',
    'longitude'     => 'Longitude',
];
