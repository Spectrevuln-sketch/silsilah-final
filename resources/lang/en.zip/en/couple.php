<?php

return [
    // Labels
    'show'               => 'Show Marriage Profile',
    'detail'             => 'Marriage Profile',
    'childs_count'       => 'Childs Count',
    'grand_childs_count' => 'Grand Childs Count',

    // Actions
    'edit'               => 'Edit Marriage',
    'update'             => 'Update Marriage',

    // Attributes
    'husband'            => 'Head of Family',
    'wife'               => 'Wife',
    'marriage_date'      => 'Marriage Date',
    'divorce_date'       => 'Divorce Date',
];